#include<iostream>
using namespace std;


int main(){
    
    int a,b;
    cout<<"enter the values for a and b\n";

    cin>>a>>b;

    cout<<"before swapping values of a and b are "<< a << " "<< b <<endl;
    a = a+b;
    b=a-b;
    a=a-b;
   
    cout<<"after swapping values of a and b are "<<a << " "<< b <<endl;

 return 0;
}

