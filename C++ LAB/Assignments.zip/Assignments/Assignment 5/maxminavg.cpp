#include<iostream>
using namespace std;

class temp
{
    int *ptr;
    int size;
    public:
    temp();
    void get();
    void show();
    int max();
     int min();
     int avg();
    
};

temp ::temp()
{
    cout<<"how many elements do you want to store\n";
    cin>> size;
    ptr = new int[size];
}

void temp:: get()
{
    cout<<"accept elements\n";
    for(int i=0; i<size;i++)
    cin>>ptr[i];
}

void temp::show()
{   
    cout<<"values are\n";
    for(int i=0; i<size;i++)
    cout<<ptr[i]<<"\n";
}
int temp::max()
{
    int m=ptr[0];
    for(int i=1; i<size; i++)
    if(ptr[i]>m)
    m=ptr[i];
    return m;
}
int temp::min()
{
    int mi=ptr[0];
    for(int i=1; i<size; i++)
    if(ptr[i]<mi)
    mi=ptr[i];
    return mi;
}
int temp::avg()
{
    int a=ptr[0];
    int sum=0, count = 0;
    for(int i=1 ;i<size; i++)
    {
    sum+=ptr[i];
    count++;
    a = sum / count;
    return a;
 }
    
    
 
}


int main()
{
    temp a;
    a.get();
    a.show();
    cout<<"maximum number is"<< a.max() << endl;
     cout<<"minimum number is" << a.min()<<endl;
     cout<<"total average is"<<a.avg()<<endl;
}