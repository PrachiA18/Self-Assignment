#include <iostream>
using namespace std;

class SortArray {
private:
    int arr[10];

public:
    // Function to take input
    void acceptData() {
        cout << "Enter 10 elements:\n";
        for (int i = 0; i < 10; i++) {
            cin >> arr[i];
        }
    }

    // Function to sort array (Ascending order)
    void sortData() {
        for (int i = 0; i < 10; i++) {
            for (int j = i + 1; j < 10; j++) {
                if (arr[i] > arr[j]) {
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
        }
    }

    // Function to display array
    void displayData() {
        cout << "Sorted Array:\n";
        for (int i = 0; i < 10; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};

// Main function
int main() {
    SortArray s;

    s.acceptData();
    s.sortData();
    s.displayData();

    return 0;
}