#include<iostream>
using namespace std;
class A
{
int x;
	
};
class B
{
int x;
   virtual void show() {}
};
int main()
{
	A a;
	B b;
	cout<<"size of object a is "<<sizeof(a);
	cout<<"size of object b is "<<sizeof(b);
}
