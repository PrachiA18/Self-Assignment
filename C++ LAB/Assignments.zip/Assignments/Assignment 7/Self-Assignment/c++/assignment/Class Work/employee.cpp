#include<iostream>
using namespace std;

class Employee
{
    int id, sal;

   public :
    Employee()
    {
        id = 001;
        sal = 10000;
    }

    Employee (int eid, int salary)
    {
        id = eid;
        sal = salary;
    }

    void display() 
    {
        cout << "employee id " << id << "salary " << sal;
    }

    void setId(int eid){
        cout<<"setter function is called";
        id = eid;
        cout << "employee id now is " << id<< endl;
    }
    void setSalary(int salary){
        sal = salary;
        cout << "Your new salary is " << sal << endl;
    }
    int getId(){
        return id;
    }
    int getSalary(){
        return sal;
    }
};

int main(){
    Employee e1;
    e1.display();
    e1.setId(2);
    e1.display();
    e1.setSalary(50000);
    int i=e1.getId();
    cout<<"id is"<<i<<endl;
    int sal = e1.getSalary();
    cout << " salary is " << sal << endl;
}