#include<iostream>
using namespace std;
int main(){
    int numerator,deniomator,result;
    cout<<"enter numerator :";
    cin>>numerator;
    cout<<"enter deniomator :";
    cin>>deniomator;

    try{
        if (deniomator==0)
        throw 0;
        else
	{
	
    result=numerator/deniomator;
    cout<<"result"<<result<<endl;

        }
        	cout<<"end";

    }
     catch(float e)
    {
    	cout<<"in 1st catch \n";
	}
	catch(int e)
	{
		cout<<"denominator should not be 0\n";
	}
	cout<<"end of the program good bye\n";

}