#include<iostream>
using namespace std;
int main()
{
    int numerator ,deniomator,arr[4]={1,2,3,4};
    int index;
    cout<<"enter arrayr index: ";
    cin>>index;

    try{
        if (index >=4)
        throw "Error :Array out of bonds !";

        cout<<"enter numerator :";
        cin>>numerator;

        cout<<"enter deniomator :";
        cin>>deniomator;
             if (denominator == 0)
            throw 0;


    
       int x = numerator / denominator;
        cout <<x;
    }

    
    catch ( const char* msg) {
        cout << msg << endl;
    }

    
    catch (int num) {
        cout << "Error: Cannot divide by " << num << endl;
    }



  return 0;        
    catch (...)
 {
        cout << "Unexpected exception!" << endl;
    }

    
  
}
    
    
