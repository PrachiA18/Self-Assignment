#include<iostream>
using namespace std;
int main(){
    int arr[5];
    int max=0;

    cout<<"enter numbers";

    for (int i = 0; i < 5; ++i) {
    cin >> arr[i];
  }

 for (int i = 0; i < 5; i++) {
      if(max<arr[i]){
        max=arr[i];
      }
 }

 cout<<max<<endl;
     

}

