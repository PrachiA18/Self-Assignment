#include <iostream>  
using namespace std;  
 void area(int,int=40);
int main() 
{
  area(40);
  area(50,100);

    return 0;  
} 
void area(int length,int breadth)
{
  cout<<length * breadth<<endl;
 } 