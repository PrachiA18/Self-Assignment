#include <iostream>  
using namespace std;  
 void add(int=40,int=50, int= 90);
int main() 
{
  add();
  add(50);
  add(10,20);

    return 0;  
} 
void add(int a,int b,int c)
{
  cout<<a+b+c<<endl;
 } 