#include<iostream>
using namespace std;

class Calculator
{
    public :
    int num1, num2;
    public:
    // Calculator(){
    //      num1 =10;
    //      num2 =12;
    // }

    // Calculator(int n1, int n2){
    //     num1 = n1;
    //     num2 = n2;
    // }

    // void display(){
    //     cout << "first number is :" << num1 << "\nSecond number is :" << num2 << endl;
    //     cin >> num1 >> num2 ;
    // }

    // void add(){
    //     int n1 = 10, n2=45;
    //     int sum = n1+n2;
    //      cout << sum << endl;
    // }

    // void display(){
    //     cout << 
    // }

    void getNumbers()
    {
        cout << "enter number  num1 = " ;
        cin >> num1;  
        
        cout << "enter number  num2 = " ;
        cin >> num2; 
    }

    void add()
    {
        cout << "addition of numbers = " << num1 + num2 << endl;
    }
     void sub()
    {
        cout << "subtraction of numbers = " << num1 - num2 << endl;
    }
     void multi()
    {
        cout << "multiplication of numbers = " << num1 * num2 <<endl;
    }
     void div()
    {
        cout << "division of numbers = " << num1 / num2 <<endl;
    }

};

int main()
{
    Calculator c1;
    // c1.display();
    // // cout << "Enter two numbers: \n" << endl;
    // Calculator c2(12,24);
    // c2.add();

    c1.getNumbers();
    c1.add();
    c1.sub();
    c1.multi();
    c1.div();
    
    
    
   
}