#include<iostream>
#include<string>

using namespace std;

class BookManagement
{
private:
    int bookId;
    string title;
    string author;
    float price;
    static int totalBooks;

public:
   BookManagement(int id, string bookName, string bookBy, float amount){
    bookId = id;
    title = bookName;
    author = bookBy;
    price = amount;
    totalBooks++;
   }


   void addBook(){
    cout <<"Enter book Id, book name, author name and price of the book" << endl;
    cin>> bookId >> title >> author >> price;
   }

   void display(){
    cout << "Book Id:" << bookId;
    cout << "bookName :" << title;
    cout << "Author:" << author;
    cout << "Price:" << price;
   }

   static void showTotalBooks(){
    cout << "Total boos are:" << totalBooks;
   }

};


int main(){
    // BookManagement b1(1, ABC, xyz, 50);
    BookManagement::showTotalBooks();

    return 0;
}



