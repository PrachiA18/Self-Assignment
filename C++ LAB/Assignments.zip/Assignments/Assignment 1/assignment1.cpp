// // Q. Write a student class and use it in your program. Store the data of 10 students and display
//  the data according to their roll numbers, dates of birth, and total marks.?

// Implement concepts such as : 
// -Classes and Objects
// -Constructors
// -Parameterized constructors



#include<iostream>
using namespace std;
class student
{
  private:
  int rollNo, day, month, year, marks;
  public:
  student()
    {
      rollNo =0;
      day ;
      month;
      year;
      marks;
    }
     student(int number, int d, int m, int y, int score)
    {
        rollNo= number;
        day = d;
        month=m;
        year=y;
        marks =score;
        
    }

    void display() 
    {
        cout << "student id is " << rollNo << " birthDate is  "<< day << "/" << month << "/" << year << " marks are "<<marks <<"%"<< endl;
    }

    void accept(     )
    {
      cout<< "\n accept roll no day month year and marks\n"<< endl;
      cin >> rollNo >> day >> month >> year >> marks;
    }
};
int main()
{
    student s11;
    s11.accept();
    s11.display();
    student s1(1,29,9,2004, 79);
    student s2(2,03,04,2005,60);
    student s3(3,04,12,2005,60);
    student s4(4,30,05,2005,60);
    student s5(5,03,04,2005,60);
    student s6(6,03,04,2005,60);
    student s7(7,03,04,2005,60);
    student s8(8,03,04,2005,60);
    student s9(9,03,04,2005,60);
    student s10(10,03,04,2005,60);
    s1.display();
    s2.display();
    s3.display();
    s4.display();
    s5.display();
    s6.display();
    s7.display();
    s8.display();
    s9.display();
    s10.display();
}